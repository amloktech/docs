AMLOK public-record research package 0.3

Read research/reproducibility.mdx for acquisition and execution commands.
This bundle includes derived artifacts, code and methods. Original public
reports and loan-row files are not redistributed. Download them only through
the documented source routes, subject to their applicable rights and terms.

The record index contains source observations, not adjudicated unique loans.
The executed results measure structured-loan classification on actual SBA
records and lexical evidence retrieval on real financial reports. Hosted frontier and AMLOK foundation-model comparisons are not run.

MANIFEST.json gives a SHA-256 digest and byte count for each packaged file.
