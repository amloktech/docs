# AMLOK research reproducibility package 0.1

This package contains an executed synthetic event-transformer experiment and a
descriptive public Bank of Canada FX analysis. No real borrower data or production
model is included. Do not use generated probabilities for lending decisions.

Use an isolated Python 3.12 environment and install scripts/research/requirements.txt.
Run scripts/research/test_research.py to verify the included predictions, arrays,
checkpoints, metrics, public-source snapshot, and selected evidence invariants.

To repeat training, run scripts/research/run_synthetic_study.py. This overwrites local
experiment outputs. To refresh the public FX acquisition, run scripts/research/public_data.py
(network access required). Preserve this original snapshot before regenerating.
Run scripts/research/render_results.py to regenerate plots and the result page.
The renderer creates research/synthetic-study.mdx and the chart directories as needed.

MANIFEST.json contains hashes and sizes of the included original artifacts.
Bank of Canada source: https://www.bankofcanada.ca/valet/docs
Source terms: https://www.bankofcanada.ca/terms/
Research documentation: https://docs.amlok.io/research
No foundation-model, real-cohort, or frontier-comparison claim is established.
