# AMLOK ruby API client

Source distribution 1.4.2, generated with OpenAPI Generator 7.17.0.

Installation and examples: https://docs.amlok.io/overview/sdks
The account manager supplies the environment URL and portal access. An authorized
administrator creates a workspace-scoped API key in the portal. Keep it server-side.
Always set the institution-issued origin; api.example.com is a placeholder.

This archive contains generated API methods and models, plus an operation index.
Operation IDs match the public API contract. No package-registry release is implied.
Generated types do not implement all JSON Schema conditional validation rules.
The published OpenAPI 3.1 contract and server validation remain authoritative.
Do not change monetary strings into floating-point amounts.

Explicitly configure timeouts and redirect handling as shown in the guide. Do not
enable blanket retries. Reuse the same idempotency key for the same action and
recover accepted commands before submitting anything again. Pagination, polling,
webhook verification and workflow orchestration are application responsibilities.
The SDK does not add financial commands, servicing, or standalone paid products.

Generated source is checked locally; it does not establish a live backend result.
Run the provisioned sandbox journeys before production use.
