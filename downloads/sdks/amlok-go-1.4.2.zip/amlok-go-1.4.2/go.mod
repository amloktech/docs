module amlok.local/client

go 1.23

require (
	gopkg.in/validator.v2 v2.0.1
)
